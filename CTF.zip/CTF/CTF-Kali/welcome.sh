#!/bin/bash

echo "Congratulations! Now you are here, explore the network and find other PCs in same subnet. The next steps are hidden in a file named after the OS of the other PC you find."
